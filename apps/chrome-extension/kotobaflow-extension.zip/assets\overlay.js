function e(e){let t=e.length,n=[],r=[];for(let r=0;r<t;r++){let t=20+r*50,i=e[r]===`H`?10:40;n.push({x:t,y:i})}if(n.length===0)return{path:``,viewBox:`0 0 0 0`,width:0,height:0};r.push(`M ${n[0].x} ${n[0].y}`);for(let e=1;e<n.length;e++)r.push(`L ${n[e].x} ${n[e].y}`);let i=n[n.length-1],a=i.x+50/2;r.push(`L ${a} ${i.y}`);let o=a+20;return{path:r.join(` `),viewBox:`0 0 ${o} 50`,width:o,height:50}}var t=null;function n(){if(t)return t;let e=document.createElement(`div`),n=e.attachShadow({mode:`closed`});return document.body.appendChild(e),t=n,n}function r(e){let r=n();r.innerHTML=`
    <style>
:host {
  all: initial;
  display: block;
  position: fixed;
  z-index: 2147483647;
  inset: 0;
  font-family: "Hiragino Kaku Gothic ProN", "Noto Sans JP", sans-serif;
}

#backdrop {
  position: absolute;
  inset: 0;
  background: rgba(0, 0, 0, 0.3);
  animation: fadeIn 0.2s ease;
}

#panel {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  max-width: 520px;
  max-height: 80vh;
  width: 90%;
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 8px 32px rgba(0,0,0,0.18);
  overflow-y: auto;
  animation: slideUp 0.25s ease;
}

@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
@keyframes slideUp { from { opacity: 0; transform: translate(-50%, -40%); } to { opacity: 1; transform: translate(-50%, -50%); } }

#header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 18px;
  border-bottom: 1px solid #f3f4f6;
}

#header h2 {
  font-size: 15px;
  font-weight: 600;
  color: #1f2937;
  margin: 0;
}

#header h2 span { color: #4F46E5; }

#close-btn {
  width: 28px;
  height: 28px;
  border: none;
  background: #f3f4f6;
  border-radius: 6px;
  cursor: pointer;
  font-size: 15px;
  line-height: 28px;
  text-align: center;
  color: #6b7280;
  transition: background 0.15s;
}

#close-btn:hover { background: #e5e7eb; color: #1f2937; }

#body {
  padding: 16px 18px;
}

.word-card {
  margin-bottom: 14px;
  border: 1px solid #f3f4f6;
  border-radius: 8px;
  padding: 12px;
}

.word-card:last-child { margin-bottom: 0; }

.word-header {
  display: flex;
  align-items: baseline;
  gap: 8px;
  margin-bottom: 6px;
}

.word-surface {
  font-size: 18px;
  font-weight: 600;
  color: #1f2937;
}

.word-reading {
  font-size: 13px;
  color: #6b7280;
}

.pattern-badge {
  display: inline-block;
  font-size: 10px;
  font-weight: 600;
  padding: 1px 7px;
  border-radius: 4px;
  margin-left: auto;
  white-space: nowrap;
}

.badge-Heiban   { background: #dbeafe; color: #1d4ed8; }
.badge-Atamadaka { background: #fce7f3; color: #be185d; }
.badge-Nakadaka  { background: #fef3c7; color: #b45309; }
.badge-Odaka     { background: #d1fae5; color: #047857; }

.word-svg {
  display: block;
  width: 100%;
  height: auto;
}

.word-svg path { stroke-width: 2.5; fill: none; stroke-linejoin: round; }

.mora-dot-H { fill: #4F46E5; r: 4; }
.mora-dot-L { fill: #9ca3af; r: 3.5; }

.mora-label {
  font-size: 9px;
  fill: #6b7280;
  text-anchor: middle;
}

.no-data {
  text-align: center;
  padding: 24px 0;
  color: #9ca3af;
  font-size: 13px;
}
</style>
    <div id="backdrop"></div>
    <div id="panel" role="dialog" aria-label="Pitch Accent Results">
      <div id="header">
        <h2><span>KotobaFlow</span> — Pitch Accent</h2>
        <button id="close-btn" aria-label="Close">&times;</button>
      </div>
      <div id="body">
        ${e.some(e=>e.pitchAccent)?e.filter(e=>e.pitchAccent).map(i).join(``):`<div class="no-data">No pitch accent data available for this selection.</div>`}
      </div>
    </div>
  `;let a=r.getElementById(`panel`),o=r.getElementById(`close-btn`),s=r.getElementById(`backdrop`),c=()=>{a.style.animation=`none`,r.host.remove(),t=null};o.addEventListener(`click`,c),s.addEventListener(`click`,c)}function i(t){let n=t.pitchAccent,r=e(n.pitchPattern.sequence);return`
    <div class="word-card">
      <div class="word-header">
        <span class="word-surface">${a(t.surface)}</span>
        <span class="word-reading">${a(n.reading)}</span>
        <span class="pattern-badge badge-${n.pitchPattern.type}">${n.pitchPattern.type}</span>
      </div>
      <svg class="word-svg" viewBox="${r.viewBox}" width="${r.width}" height="${r.height}"
           xmlns="http://www.w3.org/2000/svg">
        <path d="${r.path}" stroke="#4F46E5"/>
        ${n.pitchPattern.sequence.map((e,t)=>`<circle class="mora-dot-${e}" cx="${20+t*50}" cy="${e===`H`?10:40}"/>`).join(``)}
        ${n.pitchPattern.sequence.map((e,t)=>`<text class="mora-label" x="${20+t*50}" y="48">${t+1}</text>`).join(``)}
      </svg>
    </div>
  `}function a(e){let t={"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#039;`};return e.replace(/[&<>"']/g,e=>t[e]||e)}chrome.runtime.onMessage.addListener(e=>{e.action===`PITCH_ACCENT_RESULT`&&e.requestAction===`SHOW_PITCH_ACCENT`&&r(e.result.tokens)});