//#region src/background/index.ts
var GENKIT_API_BASE = "http://localhost:4000";
var ANALYZE_FLOW_PATH = "/api/flow/analyzeSentence";
var MENU_PARENT = "kotobaflow-parent";
var MENU_SHOW_PITCH = "show-pitch-accent";
var MENU_PREPARE_PRINT = "prepare-for-print";
chrome.runtime.onInstalled.addListener(() => {
	chrome.contextMenus.create({
		id: MENU_PARENT,
		title: "KotobaFlow AI",
		contexts: ["selection"]
	});
	chrome.contextMenus.create({
		id: MENU_SHOW_PITCH,
		parentId: MENU_PARENT,
		title: "Show Pitch Accent",
		contexts: ["selection"]
	});
	chrome.contextMenus.create({
		id: MENU_PREPARE_PRINT,
		parentId: MENU_PARENT,
		title: "Prepare for Print",
		contexts: ["selection"]
	});
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
	if (!tab?.id || !info.selectionText) return;
	switch (info.menuItemId) {
		case MENU_SHOW_PITCH:
			handleShowPitchAccent(info.selectionText, tab.id);
			break;
		case MENU_PREPARE_PRINT:
			handlePreparePrint(info.selectionText, tab.id);
			break;
	}
});
chrome.runtime.onMessage.addListener((message, sender) => {
	if (message.action === "ANALYZE_TEXT") {
		if (sender.tab?.id) handleAnalyzeText(message.text, sender.tab.id);
	}
});
async function handleShowPitchAccent(text, tabId) {
	try {
		const result = await callAnalyzeFlow(text);
		await chrome.tabs.sendMessage(tabId, {
			action: "PITCH_ACCENT_RESULT",
			requestAction: "SHOW_PITCH_ACCENT",
			result
		});
	} catch (error) {
		const message = error instanceof Error ? error.message : "Unknown error";
		await chrome.tabs.sendMessage(tabId, {
			action: "ANALYSIS_ERROR",
			requestAction: "SHOW_PITCH_ACCENT",
			error: message
		}).catch(() => {});
	}
}
async function handleAnalyzeText(text, tabId) {
	try {
		const result = await callAnalyzeFlow(text);
		await chrome.tabs.sendMessage(tabId, {
			action: "PITCH_ACCENT_RESULT",
			requestAction: "ANALYZE_TEXT",
			result
		});
	} catch (error) {
		const message = error instanceof Error ? error.message : "Unknown error";
		await chrome.tabs.sendMessage(tabId, {
			action: "ANALYSIS_ERROR",
			requestAction: "ANALYZE_TEXT",
			error: message
		}).catch(() => {});
	}
}
async function handlePreparePrint(text, tabId) {
	try {
		const result = await callAnalyzeFlow(text);
		await chrome.storage.session.set({ printData: {
			text,
			tokens: result.tokens
		} });
		await chrome.tabs.create({ url: chrome.runtime.getURL("public/print-template.html") });
	} catch (error) {
		const message = error instanceof Error ? error.message : "Unknown error";
		await chrome.tabs.sendMessage(tabId, {
			action: "ANALYSIS_ERROR",
			requestAction: "PREPARE_FOR_PRINT",
			error: message
		}).catch(() => {});
	}
}
async function callAnalyzeFlow(sentence) {
	const response = await fetch(`${GENKIT_API_BASE}${ANALYZE_FLOW_PATH}`, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({ sentence })
	});
	if (!response.ok) {
		const body = await response.text().catch(() => "");
		throw new Error(`Genkit API returned ${response.status}: ${body}`);
	}
	return response.json();
}
//#endregion
